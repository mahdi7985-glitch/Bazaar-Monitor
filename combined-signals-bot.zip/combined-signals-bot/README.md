# Combined Signals Bot (ادغام ۳ پروژه)

این ریپازیتوری سه پروژه‌ی جداگانه را در یک محل نگه‌داری می‌کند، ولی هرکدام
**کاملاً مستقل** با زمان‌بندی، توکن و آدرس API خودشان اجرا می‌شوند. هیچ آدرس
API‌ای نسبت به نسخه‌ی اصلی تغییر نکرده است.

```
combined-signals-bot/
├── tether_bot/          # سیگنال تتر/دلار (نوبیتکس + TGJU) - هر ۴ ساعت
├── gold18_bot/          # تحلیل تکنیکال طلای ۱۸ عیار (TGJU) - هر ۴ ساعت
├── goldsilver_bot/      # آربیتراژ طلا/نقره - هر ۳۰ دقیقه
└── .github/workflows/   # ۳ ورک‌فلوی جدا، هرکدام با زمان‌بندی خودش
```

## چرا ۳ ورک‌فلوی جدا؟

چون زمان‌بندی هرکدوم فرق می‌کنه (تتر و گلد-۱۸ هر ۴ ساعت، طلا-نقره هر ۳۰
دقیقه). اگه همه رو تو یک اسکریپت واحد می‌ذاشتیم، مجبور بودیم یا زمان‌بندی
طلا-نقره رو کند کنیم یا بقیه رو زیادی تند اجرا کنیم. با این ساختار هر پروژه
دقیقاً با همون سرعتی که الان داره کار می‌کنه.

## سکرت‌های موردنیاز (GitHub → Settings → Secrets and variables → Actions)

نام سکرت‌ها عمداً با پیشوند هر پروژه مشخص شدن تا تو یک ریپازیتوری با هم
تداخل نکنن. اگه بخوای یک بات تلگرام/بله رو بین چند پروژه به اشتراک بذاری،
کافیه همون مقدار توکن رو تو چند سکرت مختلف کپی کنی.

### تتر (`tether_bot`)
| Secret | توضیح |
|---|---|
| `TETHER_TELEGRAM_TOKEN` | توکن بات تلگرام |
| `TETHER_TELEGRAM_CHAT_ID` | چت‌آیدی تلگرام |
| `TETHER_BALE_TOKEN` | توکن بات بله |
| `TETHER_BALE_CHAT_ID` | چت‌آیدی بله |

### گلد-۱۸ (`gold18_bot`)
| Secret | توضیح |
|---|---|
| `GOLD18_TELEGRAM_TOKEN` | توکن بات تلگرام |
| `GOLD18_TELEGRAM_CHAT_ID` | چت‌آیدی تلگرام |
| `GOLD18_BALE_TOKEN` | توکن بات بله |
| `GOLD18_BALE_CHAT_ID` | چت‌آیدی بله |

### طلا-نقره (`goldsilver_bot`)
| Secret | توضیح |
|---|---|
| `GOLDSILVER_TELEGRAM_TOKEN` | توکن بات تلگرام |
| `GOLDSILVER_TELEGRAM_CHAT_ID` | چت‌آیدی تلگرام |
| `GOLDSILVER_BALE_TOKEN` | توکن بات بله |
| `GOLDSILVER_BALE_CHAT_ID` | چت‌آیدی بله |

## اجرای لوکال (تست)

هر پروژه یک فایل `.env` مخصوص خودش می‌خواد (کنار `main.py`/`signal_bot.py`
همون پوشه)، مثلاً برای تتر:

```
TETHER_TELEGRAM_TOKEN=...
TETHER_TELEGRAM_CHAT_ID=...
TETHER_BALE_TOKEN=...
TETHER_BALE_CHAT_ID=...
```

```bash
pip install -r requirements.txt
cd tether_bot && python signal_bot.py
```

## نکته دیباگ (باگ قبلی KeyError: 'bestSell')

تو `tether_bot/signal_bot.py`، تابع `get_tether_price` حالا قبل از دسترسی به
`bestSell` بررسی می‌کنه که کلید `usdt-rls` و `bestSell` واقعاً تو پاسخ
نوبیتکس وجود دارن؛ اگه نبودن، کل پاسخ خام رو لاگ می‌کنه تا راحت‌تر بشه فهمید
مشکل از محدودیت ساعات کاری/جغرافیایی نوبیتکسه یا تغییر ساختار پاسخ.
