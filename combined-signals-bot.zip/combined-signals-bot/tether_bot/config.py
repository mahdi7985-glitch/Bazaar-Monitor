import os
from dotenv import load_dotenv

load_dotenv()

# نکته: نام متغیرهای محیطی با پیشوند TETHER_ مشخص شدند تا در ریپازیتوری
# ترکیبی با سکرت‌های پروژه‌های دیگر (گلد-۱۸ / طلا-نقره) تداخل پیدا نکنند.
BALE_TOKEN = os.getenv("TETHER_BALE_TOKEN", "")
BALE_CHAT_ID = os.getenv("TETHER_BALE_CHAT_ID", "")

TELEGRAM_TOKEN = os.getenv("TETHER_TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TETHER_TELEGRAM_CHAT_ID", "")

THRESHOLD_NORMAL = 1.0
THRESHOLD_STRONG = 2.0
TOTAL_FEE = 0.38

# آدرس‌های API (بدون تغییر نسبت به نسخه اصلی)
NOBITEX_API_URL = "https://apiv2.nobitex.ir/market/stats?srcCurrency=usdt&dstCurrency=rls"
TGJU_DOLLAR_URL = "https://www.tgju.org/profile/price_dollar_rl"
