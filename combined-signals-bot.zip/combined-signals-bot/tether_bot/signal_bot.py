import requests
from datetime import datetime
from bs4 import BeautifulSoup
import re
import sys
import jdatetime

from config import (
    BALE_TOKEN, BALE_CHAT_ID,
    TELEGRAM_TOKEN, TELEGRAM_CHAT_ID,
    THRESHOLD_NORMAL, THRESHOLD_STRONG, TOTAL_FEE,
    NOBITEX_API_URL, TGJU_DOLLAR_URL,
)

# ==================== تبدیل تاریخ به شمسی با نام روز هفته ====================
def get_persian_datetime():
    """دریافت تاریخ و زمان شمسی با نام روز هفته به فارسی"""
    now = datetime.now()

    jalali_date = jdatetime.datetime.fromgregorian(datetime=now)

    weekdays = {
        0: "دوشنبه",
        1: "سه‌شنبه",
        2: "چهارشنبه",
        3: "پنج‌شنبه",
        4: "جمعه",
        5: "شنبه",
        6: "یک‌شنبه"
    }

    months = {
        1: "فروردین", 2: "اردیبهشت", 3: "خرداد",
        4: "تیر", 5: "مرداد", 6: "شهریور",
        7: "مهر", 8: "آبان", 9: "آذر",
        10: "دی", 11: "بهمن", 12: "اسفند"
    }

    weekday_num = jalali_date.weekday()
    weekday_name = weekdays.get(weekday_num, "")

    jalali_with_weekday = f"{weekday_name} {jalali_date.day} {months.get(jalali_date.month, '')} {jalali_date.year}"
    time_str = now.strftime("%H:%M")

    return jalali_with_weekday, time_str


# ==================== دریافت قیمت دلار از TGJU ====================
def get_dollar_price_from_tgju():
    try:
        print("🔍 تلاش برای دریافت قیمت دلار از TGJU...")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        response = requests.get(TGJU_DOLLAR_URL, headers=headers, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')

        price_element = soup.find('span', {'data-col': 'last'})
        if price_element:
            price_text = price_element.get_text().strip()
            clean_price = re.sub(r'[^\d.]', '', price_text)
            if clean_price:
                price = float(clean_price)
                if price > 1000:
                    price = price / 10
                print(f"✅ قیمت دلار از TGJU دریافت شد: {price:,.0f} تومان")
                return price

        text = soup.get_text()
        numbers = re.findall(r'(\d{1,3}(?:,\d{3})*\.?\d*)', text)
        for num in numbers:
            clean_num = num.replace(',', '')
            if clean_num.replace('.', '').isdigit():
                price = float(clean_num)
                if 100000 < price < 10000000:
                    price = price / 10
                    print(f"✅ قیمت دلار از TGJU دریافت شد: {price:,.0f} تومان")
                    return price

        print("⚠️ قیمت دلار در TGJU پیدا نشد.")
        return None

    except Exception as e:
        print(f"❌ خطا در دریافت قیمت از TGJU: {e}")
        return None


# ==================== دریافت قیمت تتر از نوبیتکس ====================
def get_tether_price():
    """
    دریافت قیمت تتر از API نوبیتکس.
    نکته دیباگ: در صورت تغییر ساختار پاسخ (مثلاً نبود کلید bestSell یا
    محدودیت جغرافیایی/ساعات کاری نوبیتکس روی رانرهای گیت‌هاب)، کل پاسخ
    خام برای بررسی راحت‌تر چاپ می‌شود.
    """
    try:
        print("🔍 دریافت قیمت تتر از نوبیتکس...")
        response_tether = requests.get(NOBITEX_API_URL, timeout=15)

        if response_tether.status_code != 200:
            print(f"❌ خطا در دریافت قیمت تتر: کد وضعیت {response_tether.status_code}")
            print(f"↪️ متن پاسخ: {response_tether.text[:500]}")
            return None

        tether_data = response_tether.json()

        stats = tether_data.get('stats', {})
        pair_data = stats.get('usdt-rls')

        if pair_data is None:
            print("❌ کلید 'usdt-rls' در پاسخ نوبیتکس پیدا نشد.")
            print(f"↪️ کلیدهای موجود در stats: {list(stats.keys())[:20]}")
            return None

        best_sell = pair_data.get('bestSell')
        if best_sell is None:
            print("❌ کلید 'bestSell' در داده جفت‌ارز usdt-rls پیدا نشد.")
            print(f"↪️ محتوای usdt-rls: {pair_data}")
            return None

        tether_price = float(best_sell) / 10
        print(f"✅ قیمت تتر از نوبیتکس دریافت شد: {tether_price:,.0f} تومان")
        return tether_price

    except Exception as e:
        print(f"❌ خطا در دریافت قیمت تتر: {e}")
        return None


# ==================== دریافت قیمت‌ها ====================
def get_prices():
    tether_price = get_tether_price()
    if tether_price is None:
        return None, None

    dollar_price = get_dollar_price_from_tgju()

    if dollar_price is None or dollar_price == 0:
        print("⚠️ عدم دسترسی به قیمت دلار. از قیمت تتر به عنوان تخمین استفاده می‌شود.")
        dollar_price = tether_price

    print(f"💵 قیمت نهایی: دلار {dollar_price:,.0f} | تتر {tether_price:,.0f} تومان")
    return tether_price, dollar_price


# ==================== تحلیل و ساخت سیگنال ====================
def get_emoji(diff):
    if abs(diff) >= THRESHOLD_STRONG:
        return "🟣"
    elif abs(diff) >= THRESHOLD_NORMAL:
        return "🔵"
    else:
        return "⚪"


def get_friendly_suggestion(signal_type, diff_percent, net_profit):
    if signal_type == "SELL":
        return f"""✅ **پیشنهاد من به شما:**
فروش تتر در این لحظه می‌تونه انتخاب خوبی باشه! تتر حدوداً {diff_percent:.2f}٪ از دلار گران‌تر شده و این یعنی شما می‌تونید تترهاتون رو بفروشید و با سود حدوداً {net_profit:.2f}٪ ریال دریافت کنید.
🚀 پیشنهاد می‌کنم سریعاً اقدام کنید قبل از اینکه بازار برگردد!"""

    elif signal_type == "BUY":
        return f"""✅ **پیشنهاد من به شما:**
الان وقت خرید تتره! دلار حدوداً {abs(diff_percent):.2f}٪ از تتر گران‌تر شده. یعنی می‌تونید با ریالتون تتر بخرید و وقتی بازار متعادل شد، با سود حدوداً {net_profit:.2f}٪ بفروشید.
🟢 به نظر می‌رسه یه فرصت خوب پیش اومده، ازش استفاده کنید!"""

    else:
        return f"""⏳ **پیشنهاد من به شما:**
همین الان بازار خیلی آرومه و اختلاف قیمت فقط {diff_percent:.2f}٪ هست. این اختلاف برای سوددهی کافی نیست (چون کارمزدها حدوداً {TOTAL_FEE:.2f}٪ هستن).
پس فعلاً **دست نگه دارید** و صبر کنید. وقتی اختلاف به بالای {THRESHOLD_NORMAL}٪ رسید، من به شما خبر می‌دم!
🧘‍♂️ آروم باشید و به ربات اعتماد کنید. 😊"""


def check_opportunity(tether, dollar):
    if tether is None or dollar is None:
        return "ERROR", "❌ خطا در دریافت قیمت‌ها"

    diff_percent = ((tether - dollar) / dollar) * 100
    net_profit = abs(diff_percent) - TOTAL_FEE
    emoji = get_emoji(diff_percent)

    persian_date, persian_time = get_persian_datetime()

    if diff_percent > THRESHOLD_NORMAL:
        signal_type = "SELL"
    elif diff_percent < -THRESHOLD_NORMAL:
        signal_type = "BUY"
    else:
        signal_type = "NONE"

    suggestion = get_friendly_suggestion(signal_type, diff_percent, net_profit)

    if diff_percent > THRESHOLD_NORMAL:
        msg = f"""{emoji} **سیگنال فروش تتر**

🔹 اختلاف قیمت: **{diff_percent:.2f}%**
💰 سود خالص تقریبی: **{net_profit:.2f}%**
💡 تتر {diff_percent:.2f}% از دلار گران‌تر است.

{suggestion}

📅 {persian_date} - 🕐 {persian_time}"""
        return "SELL", msg

    elif diff_percent < -THRESHOLD_NORMAL:
        msg = f"""{emoji} **سیگنال خرید تتر**

🔹 اختلاف قیمت: **{abs(diff_percent):.2f}%**
💰 سود خالص تقریبی: **{net_profit:.2f}%**
💡 دلار {abs(diff_percent):.2f}% از تتر گران‌تر است.

{suggestion}

📅 {persian_date} - 🕐 {persian_time}"""
        return "BUY", msg

    else:
        msg = f"""⚪ **بازار در تعادل**

🔹 اختلاف فعلی: **{diff_percent:.2f}%**
🔸 آستانه مورد نیاز برای سیگنال: **{THRESHOLD_NORMAL}%**
💵 قیمت تتر: **{tether:,.0f}** تومان
💵 قیمت دلار: **{dollar:,.0f}** تومان

{suggestion}

📅 {persian_date} - 🕐 {persian_time}"""
        return "NONE", msg


# ==================== ارسال پیام به بله ====================
def send_to_bale(msg):
    if not BALE_TOKEN or not BALE_CHAT_ID:
        print("⚠️ TETHER_BALE_TOKEN یا TETHER_BALE_CHAT_ID تنظیم نشده")
        return False

    urls = [
        f"https://api.bale.ai/bot{BALE_TOKEN}/sendMessage",
        f"https://tapi.bale.ai/bot{BALE_TOKEN}/sendMessage"
    ]
    for url in urls:
        try:
            response = requests.post(url, json={
                "chat_id": BALE_CHAT_ID,
                "text": msg,
                "parse_mode": "Markdown"
            }, timeout=15)
            if response.status_code == 200:
                print("✅ پیام به بله ارسال شد")
                return True
            else:
                print(f"❌ خطا در بله ({url}): {response.status_code}")
        except Exception as e:
            print(f"❌ خطا در بله ({url}): {e}")
    return False


# ==================== ارسال پیام به تلگرام ====================
def send_to_telegram(msg):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        print("⚠️ TETHER_TELEGRAM_TOKEN یا TETHER_TELEGRAM_CHAT_ID تنظیم نشده")
        return False

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    try:
        response = requests.post(url, json={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": msg,
            "parse_mode": "Markdown"
        }, timeout=15)
        if response.status_code == 200:
            print("✅ پیام به تلگرام ارسال شد")
            return True
        else:
            print(f"❌ خطا در تلگرام: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ خطا در تلگرام: {e}")
        return False


# ==================== تابع اصلی ====================
def main():
    print("🤖 ربات سیگنال‌دهنده تتر شروع به کار کرد...")
    print("📊 در حال دریافت قیمت‌های لحظه‌ای...")

    tether_price, dollar_price = get_prices()

    if tether_price is None or dollar_price is None:
        print("❌ دریافت قیمت ناموفق. ربات متوقف شد.")
        return

    signal_type, message = check_opportunity(tether_price, dollar_price)

    print("-" * 50)
    print(f"💵 قیمت تتر: {tether_price:,.0f} تومان")
    print(f"💵 قیمت دلار: {dollar_price:,.0f} تومان")
    print(f"📊 اختلاف قیمت: {((tether_price - dollar_price) / dollar_price) * 100:.2f}%")
    print(f"📊 نوع سیگنال: {signal_type}")
    print("-" * 50)

    print("📤 در حال ارسال پیام...")

    bale_result = send_to_bale(message)
    telegram_result = send_to_telegram(message)

    if bale_result or telegram_result:
        print("✅ پیام حداقل به یکی از پیام‌رسان‌ها ارسال شد.")
    else:
        print("❌ ارسال پیام به هر دو پیام‌رسان ناموفق بود.")


if __name__ == "__main__":
    main()
